using System;
using System.Collections.Generic;
using JOIEnergy.Services;
using JOIEnergy.Domain;
using Xunit;

namespace JOIEnergy.Tests
{
    /// <summary>
    /// Unit tests for the MeterReadingService class.
    /// Tests functionality for storing and retrieving electricity readings from smart meters.
    /// </summary>
    public class MeterReadingServiceTest
    {
        /// <summary>
        /// Test smart meter identifier used across test methods.
        /// </summary>
        private static string SMART_METER_ID = "smart-meter-id";

        /// <summary>
        /// Instance of the meter reading service being tested.
        /// </summary>
        private MeterReadingService meterReadingService;

        /// <summary>
        /// Test setup - initializes the meter reading service with test data.
        /// Prepopulates the service with sample electricity readings for testing.
        /// </summary>
        public MeterReadingServiceTest()
        {
            // Initialize service with empty readings storage
            meterReadingService = new MeterReadingService(new Dictionary<string, List<ElectricityReading>>());

            // Store initial test readings for the test smart meter
            meterReadingService.StoreReadings(SMART_METER_ID, new List<ElectricityReading>() {
                new ElectricityReading() { Time = DateTime.Now.AddMinutes(-30), Reading = 35m },
                new ElectricityReading() { Time = DateTime.Now.AddMinutes(-15), Reading = 30m }
            });
        }

        /// <summary>
        /// Tests that the service returns an empty list when requesting readings 
        /// for a smart meter that doesn't exist in the system.
        /// </summary>
        [Fact]
        public void GivenMeterIdThatDoesNotExistShouldReturnNull() {
            // Act & Assert: Verify empty result for unknown meter ID
            Assert.Empty(meterReadingService.GetReadings("unknown-id"));
        }

        /// <summary>
        /// Tests that the service correctly stores and retrieves electricity readings.
        /// Verifies that new readings are appended to existing readings for a meter.
        /// </summary>
        [Fact]
        public void GivenMeterReadingThatExistsShouldReturnMeterReadings()
        {
            // Arrange: Add additional reading to existing meter
            meterReadingService.StoreReadings(SMART_METER_ID, new List<ElectricityReading>() {
                new ElectricityReading() { Time = DateTime.Now, Reading = 25m }
            });

            // Act: Retrieve all readings for the meter
            var electricityReadings = meterReadingService.GetReadings(SMART_METER_ID);

            // Assert: Verify total count includes initial + newly added readings
            Assert.Equal(3, electricityReadings.Count);
        }
    }
}