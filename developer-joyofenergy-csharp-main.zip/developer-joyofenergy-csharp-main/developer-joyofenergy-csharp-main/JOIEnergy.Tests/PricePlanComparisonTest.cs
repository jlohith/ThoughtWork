﻿using JOIEnergy.Controllers;
using JOIEnergy.Domain;
using JOIEnergy.Enums;
using JOIEnergy.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using Xunit;
using Newtonsoft.Json.Linq;
using System.Collections;

namespace JOIEnergy.Tests
{
    /// <summary>
    /// Unit tests for the PricePlanComparatorController class.
    /// Tests the functionality of price plan comparison and recommendation endpoints,
    /// including cost calculations across different price plans and response formatting.
    /// </summary>
    public class PricePlanComparisonTest
    {
        /// <summary>
        /// Test meter reading service instance used across test methods.
        /// </summary>
        private MeterReadingService meterReadingService;

        /// <summary>
        /// Test controller instance being tested.
        /// </summary>
        private PricePlanComparatorController controller;

        /// <summary>
        /// Test price plan identifier for the most expensive plan (unit rate: 10).
        /// </summary>
        private static string PRICE_PLAN_1_ID = "test-supplier";

        /// <summary>
        /// Test price plan identifier for the cheapest plan (unit rate: 1).
        /// </summary>
        private static string PRICE_PLAN_2_ID = "best-supplier";

        /// <summary>
        /// Test price plan identifier for the medium-priced plan (unit rate: 2).
        /// </summary>
        private static string PRICE_PLAN_3_ID = "second-best-supplier";

        /// <summary>
        /// Test smart meter identifier used in test scenarios.
        /// </summary>
        private static string SMART_METER_ID = "smart-meter-id";

        /// <summary>
        /// Test setup - initializes test dependencies and sets up the controller with test data.
        /// Creates three price plans with different unit rates (10, 1, 2) for comparison testing.
        /// Associates the test smart meter with the most expensive price plan.
        /// </summary>
        public PricePlanComparisonTest()
        {
            // Initialize empty readings storage
            var readings = new Dictionary<string,List<Domain.ElectricityReading>>();
            meterReadingService = new MeterReadingService(readings);

            // Create test price plans with different rates for comparison testing
            var pricePlans = new List<PricePlan>() {
                new PricePlan() { PlanName = PRICE_PLAN_1_ID, UnitRate = 10, PeakTimeMultiplier = NoMultipliers() },
                new PricePlan() { PlanName = PRICE_PLAN_2_ID, UnitRate = 1, PeakTimeMultiplier = NoMultipliers() },
                new PricePlan() { PlanName = PRICE_PLAN_3_ID, UnitRate = 2, PeakTimeMultiplier = NoMultipliers() }
            };

            // Initialize price plan service with test data
            var pricePlanService = new PricePlanService(pricePlans,meterReadingService);

            // Set up account mapping for test smart meter (associated with most expensive plan)
            var smartMeterToPricePlanAccounts = new Dictionary<string,string>
            {
                { SMART_METER_ID, PRICE_PLAN_1_ID }
            };
            var accountService = new AccountService(smartMeterToPricePlanAccounts);

            // Initialize controller with test services
            controller = new PricePlanComparatorController(pricePlanService,accountService);
        }

        /// <summary>
        /// Tests that the controller correctly calculates costs for all price plans
        /// when given electricity readings for a smart meter.
        /// Verifies both the current price plan ID and cost calculations for each plan.
        /// Uses a 1-hour time span with readings of 15.0 and 5.0 for predictable calculations.
        /// Expected: average (15+5)/2 = 10, time = 1 hour, hourly rate = 10
        /// Plan costs: Plan1 = 10*10 = 100, Plan2 = 10*1 = 10, Plan3 = 10*2 = 20
        /// </summary>
        [Fact]
        public void ShouldCalculateCostForMeterReadingsForEveryPricePlan()
        {
            // Arrange: Create test electricity readings with 1-hour time span
            var electricityReading = new ElectricityReading() { Time = DateTime.Now.AddHours(-1),Reading = 15.0m };
            var otherReading = new ElectricityReading() { Time = DateTime.Now,Reading = 5.0m };
            meterReadingService.StoreReadings(SMART_METER_ID,new List<ElectricityReading>() { electricityReading,otherReading });

            // Act: Calculate costs for all price plans
            Dictionary<string,object> result = controller.CalculatedCostForEachPricePlan(SMART_METER_ID).Value as Dictionary<string,object>;

            // Assert: Verify response structure and calculated costs
            Assert.NotNull(result);
            Assert.Equal(PRICE_PLAN_1_ID,result[PricePlanComparatorController.PRICE_PLAN_ID_KEY]);
            var expected = new Dictionary<string,decimal>() {
                { PRICE_PLAN_1_ID, 100m },
                { PRICE_PLAN_2_ID, 10m },
                { PRICE_PLAN_3_ID, 20m },
            };
            Assert.Equal(expected,result[PricePlanComparatorController.PRICE_PLAN_COMPARISONS_KEY]);
        }

        /// <summary>
        /// Tests price plan recommendations without a limit parameter.
        /// Verifies that all price plans are returned sorted by cost (cheapest first).
        /// Uses a 30-minute time span with readings of 35 and 3.
        /// Expected: average (35+3)/2 = 19, time = 0.5 hours, hourly rate = 38
        /// Plan costs: Plan2 = 38*1 = 38, Plan3 = 38*2 = 76, Plan1 = 38*10 = 380
        /// </summary>
        [Fact]
        public void ShouldRecommendCheapestPricePlansNoLimitForMeterUsage()
        {
            // Arrange: Store test readings with 30-minute time span
            meterReadingService.StoreReadings(SMART_METER_ID,new List<ElectricityReading>() {
                new ElectricityReading() { Time = DateTime.Now.AddMinutes(-30), Reading = 35m },
                new ElectricityReading() { Time = DateTime.Now, Reading = 3m }
            });

            // Act: Get recommendations without limit
            object result = controller.RecommendCheapestPricePlans(SMART_METER_ID,null).Value;

            // Assert: Verify recommendations are sorted by cost (cheapest first)
            var recommendations = ((IEnumerable<KeyValuePair<string,decimal>>)result).ToList();
            var expected = new List<KeyValuePair<string,decimal>>() {
                new(PRICE_PLAN_2_ID, 38m),   // Cheapest
                new(PRICE_PLAN_3_ID, 76m),   // Medium
                new(PRICE_PLAN_1_ID, 380m),  // Most expensive
            };
            Assert.Equal(expected,recommendations);
        }

        /// <summary>
        /// Tests price plan recommendations with a limit parameter.
        /// Verifies that only the specified number of cheapest plans are returned.
        /// Uses a 45-minute time span with readings of 5 and 20, limiting results to top 2.
        /// Expected: average (5+20)/2 = 12.5, time = 0.75 hours, hourly rate = 16.667
        /// Returns only the 2 cheapest plans.
        /// </summary>
        [Fact]
        public void ShouldRecommendLimitedCheapestPricePlansForMeterUsage()
        {
            // Arrange: Store test readings with 45-minute time span
            meterReadingService.StoreReadings(SMART_METER_ID,new List<ElectricityReading>() {
                new ElectricityReading() { Time = DateTime.Now.AddMinutes(-45), Reading = 5m },
                new ElectricityReading() { Time = DateTime.Now, Reading = 20m }
            });

            // Act: Get limited recommendations (top 2)
            object result = controller.RecommendCheapestPricePlans(SMART_METER_ID,2).Value;

            // Assert: Verify only 2 recommendations returned
            var recommendations = ((IEnumerable<KeyValuePair<string,decimal>>)result).ToList();
            var expected = new List<KeyValuePair<string,decimal>>() {
                new(PRICE_PLAN_2_ID, 16.667m),
                new(PRICE_PLAN_3_ID, 33.333m),
            };
            Assert.Equal(expected,recommendations);
        }

        /// <summary>
        /// Tests price plan recommendations when the limit exceeds available plans.
        /// Verifies that all available plans are returned when limit is higher than plan count.
        /// Uses a 60-minute time span with readings of 25 and 3, requesting 5 recommendations
        /// (more than the 3 available plans).
        /// Expected: average (25+3)/2 = 14, time = 1 hour, hourly rate = 14
        /// </summary>
        [Fact]
        public void ShouldRecommendCheapestPricePlansMoreThanLimitAvailableForMeterUsage()
        {
            // Arrange: Store test readings with 60-minute time span
            meterReadingService.StoreReadings(SMART_METER_ID,new List<ElectricityReading>() {
                new ElectricityReading() { Time = DateTime.Now.AddMinutes(-60), Reading = 25m },
                new ElectricityReading() { Time = DateTime.Now, Reading = 3m }
            });

            // Act: Request more recommendations than available plans
            object result = controller.RecommendCheapestPricePlans(SMART_METER_ID,5).Value;

            // Assert: Verify all 3 plans returned (limit exceeds available plans)
            var recommendations = ((IEnumerable<KeyValuePair<string,decimal>>)result).ToList();
            var expected = new List<KeyValuePair<string,decimal>>() {
                new(PRICE_PLAN_2_ID, 14m),
                new(PRICE_PLAN_3_ID, 28m),
                new(PRICE_PLAN_1_ID, 140m),
            };
            Assert.Equal(expected,recommendations);
        }

        /// <summary>
        /// Tests error handling when requesting data for a non-existent meter ID.
        /// Verifies that a 404 Not Found status is returned when no readings exist for the meter.
        /// This ensures proper error handling for invalid meter requests.
        /// </summary>
        [Fact]
        public void GivenNoMatchingMeterIdShouldReturnNotFound()
        {
            // Act & Assert: Verify 404 status for non-existent meter
            Assert.Equal(404,controller.CalculatedCostForEachPricePlan("not-found").StatusCode);
        }

        /// <summary>
        /// Helper method to create an empty list of peak time multipliers for test price plans.
        /// Used to simplify price plan setup by avoiding peak time complexity in basic cost tests.
        /// </summary>
        /// <returns>Empty list of PeakTimeMultiplier objects</returns>
        private static List<PeakTimeMultiplier> NoMultipliers()
        {
            return new List<PeakTimeMultiplier>();
        }
    }
}