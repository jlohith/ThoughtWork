﻿using System;
using System.Collections.Generic;
using JOIEnergy.Domain;
using JOIEnergy.Enums;
using Xunit;

namespace JOIEnergy.Tests
{
    /// <summary>
    /// Unit tests for the PricePlan class.
    /// Tests the functionality of price calculations including base rates and peak time multipliers.
    /// </summary>
    public class PricePlanTest
    {
        /// <summary>
        /// Test instance of PricePlan configured with peak time multipliers for testing.
        /// </summary>
        private PricePlan _pricePlan;

        /// <summary>
        /// Test setup - initializes a PricePlan with base rate and weekend peak time multipliers.
        /// Creates a plan with TheGreenEco supplier, 20m base rate, and higher rates on weekends.
        /// </summary>
        public PricePlanTest()
        {
            _pricePlan = new PricePlan
            {
                EnergySupplier = Supplier.TheGreenEco,
                UnitRate = 20m,
                PeakTimeMultiplier = new List<PeakTimeMultiplier> {
                    new PeakTimeMultiplier {
                        DayOfWeek = DayOfWeek.Saturday,
                        Multiplier = 2m  // Double rate on Saturday
                    },
                    new PeakTimeMultiplier {
                        DayOfWeek = DayOfWeek.Sunday,
                        Multiplier = 10m  // 10x rate on Sunday
                    }
                }
            };
        }

        /// <summary>
        /// Tests that the PricePlan correctly returns the configured energy supplier.
        /// Verifies the EnergySupplier property is properly set and retrieved.
        /// </summary>
        [Fact]
        public void TestGetEnergySupplier()
        {
            // Assert: Verify the energy supplier matches the configured value
            Assert.Equal(Supplier.TheGreenEco,_pricePlan.EnergySupplier);
        }

        /// <summary>
        /// Tests that the PricePlan returns the base unit rate when no peak time multiplier applies.
        /// Uses Tuesday, January 2, 2018 which has no configured peak time multiplier.
        /// </summary>
        [Fact]
        public void TestGetBasePrice()
        {
            // Act & Assert: Verify base rate is returned for non-peak day (Tuesday)
            Assert.Equal(20m,_pricePlan.GetPrice(new DateTime(2018,1,2)));
        }

        /// <summary>
        /// Tests that the PricePlan correctly applies peak time multipliers.
        /// Uses Saturday, January 6, 2018 which should apply the 2x multiplier (20 * 2 = 40).
        /// </summary>
        [Fact]
        public void TestGetPeakTimePrice()
        {
            // Act & Assert: Verify peak time multiplier is applied for Saturday (2x multiplier)
            Assert.Equal(40m,_pricePlan.GetPrice(new DateTime(2018,1,6)));
        }
    }
}