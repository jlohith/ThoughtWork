using System;
using System.Collections.Generic;
using JOIEnergy.Enums;
using JOIEnergy.Services;
using Xunit;

namespace JOIEnergy.Tests
{
    /// <summary>
    /// Unit tests for the AccountService class.
    /// Tests the functionality of retrieving price plan associations for smart meters,
    /// including both successful lookups and handling of non-existent meter IDs.
    /// </summary>
    public class AccountServiceTest
    {
        /// <summary>
        /// Test price plan identifier used for associating with the test smart meter.
        /// </summary>
        private const string PRICE_PLAN_ID = "price-plan-id";

        /// <summary>
        /// Test smart meter identifier used in test scenarios.
        /// </summary>
        private const string SMART_METER_ID = "smart-meter-id";

        /// <summary>
        /// Instance of the AccountService being tested.
        /// </summary>
        private AccountService accountService;

        /// <summary>
        /// Test setup - initializes the AccountService with test data.
        /// Creates a mapping between a test smart meter and price plan for testing lookups.
        /// </summary>
        public AccountServiceTest()
        {
            // Create test mapping of smart meter to price plan
            var smartMeterToPricePlanAccounts = new Dictionary<string,string>();
            smartMeterToPricePlanAccounts.Add(SMART_METER_ID,PRICE_PLAN_ID);

            // Initialize service with test data
            accountService = new AccountService(smartMeterToPricePlanAccounts);
        }

        /// <summary>
        /// Tests that the AccountService correctly returns the associated price plan ID
        /// when given a valid smart meter ID that exists in the system.
        /// Verifies the basic lookup functionality works as expected.
        /// </summary>
        [Fact]
        public void GivenTheSmartMeterIdReturnsThePricePlanId()
        {
            // Act: Retrieve price plan ID for known smart meter
            var result = accountService.GetPricePlanIdForSmartMeterId(SMART_METER_ID);

            // Assert: Verify correct price plan ID is returned
            Assert.Equal(PRICE_PLAN_ID,result);
        }

        /// <summary>
        /// Tests that the AccountService correctly handles requests for smart meter IDs
        /// that don't exist in the system by returning null.
        /// Verifies proper error handling for non-existent meters.
        /// </summary>
        [Fact]
        public void GivenAnUnknownSmartMeterIdReturnsNull()
        {
            // Act: Attempt to retrieve price plan for non-existent smart meter
            var result = accountService.GetPricePlanIdForSmartMeterId("non-existent");

            // Assert: Verify null is returned for unknown meter ID
            Assert.Null(result);
        }
    }
}