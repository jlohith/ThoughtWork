﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace JOIEnergy
{
    /// <summary>
    /// Main entry point for the JOI Energy application.
    /// Configures and starts the ASP.NET Core web host for the energy consumption tracking API.
    /// </summary>
    public class Program
    {
        /// <summary>
        /// Application entry point. Builds and starts the web host.
        /// </summary>
        /// <param name="args">Command line arguments passed to the application</param>
        public static void Main(string[] args)
        {
            BuildWebHost(args).Run();
        }

        /// <summary>
        /// Builds and configures the web host with default settings and Startup configuration.
        /// </summary>
        /// <param name="args">Command line arguments for host configuration</param>
        /// <returns>Configured IWebHost instance ready to be started</returns>
        public static IWebHost BuildWebHost(string[] args) =>
            WebHost.CreateDefaultBuilder(args)
                .UseStartup<Startup>()
                .Build();
    }
}
