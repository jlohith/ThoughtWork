﻿using System;
using System.Collections.Generic;
using System.Linq;
using JOIEnergy.Domain;
using JOIEnergy.Generator;
using JOIEnergy.Services;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.DependencyInjection;

namespace JOIEnergy
{
    /// <summary>
    /// Startup configuration class for the JOI Energy application.
    /// Configures services, dependency injection, and the HTTP request pipeline.
    /// Sets up initial data for development and testing purposes.
    /// </summary>
    public class Startup
    {
        /// <summary>
        /// Price plan identifier for the most expensive energy supplier.
        /// </summary>
        private const string MOST_EVIL_PRICE_PLAN_ID = "price-plan-0";
        
        /// <summary>
        /// Price plan identifier for the renewable energy supplier.
        /// </summary>
        private const string RENEWABLES_PRICE_PLAN_ID = "price-plan-1";
        
        /// <summary>
        /// Price plan identifier for the standard energy supplier.
        /// </summary>
        private const string STANDARD_PRICE_PLAN_ID = "price-plan-2";

        /// <summary>
        /// Initializes a new instance of the Startup class with configuration.
        /// </summary>
        /// <param name="configuration">Application configuration settings</param>
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        /// <summary>
        /// Gets the application configuration settings.
        /// </summary>
        public IConfiguration Configuration { get; }

        /// <summary>
        /// Configures services for dependency injection.
        /// Sets up MVC, business services, and initial data for the application.
        /// </summary>
        /// <param name="services">The service collection to configure</param>
        public void ConfigureServices(IServiceCollection services)
        {
            // Generate initial meter readings for development/testing
            var readings = GenerateMeterElectricityReadings();

            // Define available price plans with different rates and suppliers
            var pricePlans = new List<PricePlan> {
                new PricePlan{
                    PlanName = MOST_EVIL_PRICE_PLAN_ID,
                    EnergySupplier = Enums.Supplier.DrEvilsDarkEnergy,
                    UnitRate = 10m,  // Highest rate
                    PeakTimeMultiplier = new List<PeakTimeMultiplier>()
                },
                new PricePlan{
                    PlanName = RENEWABLES_PRICE_PLAN_ID,
                    EnergySupplier = Enums.Supplier.TheGreenEco,
                    UnitRate = 2m,   // Medium rate
                    PeakTimeMultiplier = new List<PeakTimeMultiplier>()
                },
                new PricePlan{
                    PlanName = STANDARD_PRICE_PLAN_ID,
                    EnergySupplier = Enums.Supplier.PowerForEveryone,
                    UnitRate = 1m,   // Lowest rate
                    PeakTimeMultiplier = new List<PeakTimeMultiplier>()
                }
            };

            // Configure ASP.NET Core MVC with legacy routing disabled
            services.AddMvc(options => options.EnableEndpointRouting = false);
            
            // Register business services for dependency injection
            services.AddTransient<IAccountService, AccountService>();
            services.AddTransient<IMeterReadingService, MeterReadingService>();
            services.AddTransient<IPricePlanService, PricePlanService>();
            
            // Register data as singletons for the application lifetime
            services.AddSingleton((IServiceProvider arg) => readings);
            services.AddSingleton((IServiceProvider arg) => pricePlans);
            services.AddSingleton((IServiceProvider arg) => SmartMeterToPricePlanAccounts);
        }

        /// <summary>
        /// Configures the HTTP request pipeline.
        /// Sets up middleware for handling requests and responses.
        /// </summary>
        /// <param name="app">The application builder</param>
        /// <param name="env">The web host environment</param>
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            // Enable detailed error pages in development environment
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            // Use MVC routing for API endpoints
            app.UseMvc();
        }

        /// <summary>
        /// Generates initial electricity readings for all configured smart meters.
        /// Creates 20 readings per meter for development and testing purposes.
        /// </summary>
        /// <returns>Dictionary mapping smart meter IDs to their generated electricity readings</returns>
        private Dictionary<string, List<ElectricityReading>> GenerateMeterElectricityReadings() {
            var readings = new Dictionary<string, List<ElectricityReading>>();
            var generator = new ElectricityReadingGenerator();
            
            // Get all smart meter IDs from the account mappings
            var smartMeterIds = SmartMeterToPricePlanAccounts.Select(mtpp => mtpp.Key);

            // Generate readings for each smart meter
            foreach (var smartMeterId in smartMeterIds)
            {
                readings.Add(smartMeterId, generator.Generate(20));
            }
            return readings;
        }

        /// <summary>
        /// Gets the predefined mapping of smart meters to their assigned price plans.
        /// Used for customer account management and price plan associations.
        /// </summary>
        public Dictionary<string, string> SmartMeterToPricePlanAccounts
        {
            get
            {
                Dictionary<string, string> smartMeterToPricePlanAccounts = new Dictionary<string, string>();
                
                // Map each smart meter to a specific price plan for testing/demo purposes
                smartMeterToPricePlanAccounts.Add("smart-meter-0", MOST_EVIL_PRICE_PLAN_ID);
                smartMeterToPricePlanAccounts.Add("smart-meter-1", RENEWABLES_PRICE_PLAN_ID);
                smartMeterToPricePlanAccounts.Add("smart-meter-2", MOST_EVIL_PRICE_PLAN_ID);
                smartMeterToPricePlanAccounts.Add("smart-meter-3", STANDARD_PRICE_PLAN_ID);
                smartMeterToPricePlanAccounts.Add("smart-meter-4", RENEWABLES_PRICE_PLAN_ID);
                
                return smartMeterToPricePlanAccounts;
            }
        }
    }
}
