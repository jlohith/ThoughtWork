﻿using System;

namespace JOIEnergy.Enums
{
    /// <summary>
    /// Enumeration of available energy suppliers in the JOI Energy platform.
    /// Each supplier represents a different energy company with varying pricing models.
    /// </summary>
    public enum Supplier
    {
        /// <summary>
        /// Dr. Evil's Dark Energy - A fictional high-cost energy supplier
        /// </summary>
        DrEvilsDarkEnergy,
        
        /// <summary>
        /// The Green Eco - An environmentally conscious energy supplier
        /// </summary>
        TheGreenEco,
        
        /// <summary>
        /// Power For Everyone - A supplier focused on accessible energy pricing
        /// </summary>
        PowerForEveryone,
        
        /// <summary>
        /// Null Supplier - Used as a default or placeholder when no supplier is specified
        /// </summary>
        NullSupplier
    }
}
