﻿using System;
using System.Collections.Generic;
using JOIEnergy.Domain;

namespace JOIEnergy.Generator
{
    /// <summary>
    /// Utility class for generating mock electricity reading data for testing and development purposes.
    /// Creates realistic electricity readings with timestamps and random consumption values.
    /// </summary>
    public class ElectricityReadingGenerator
    {
        /// <summary>
        /// Initializes a new instance of the ElectricityReadingGenerator.
        /// </summary>
        public ElectricityReadingGenerator()
        {

        }
        
        /// <summary>
        /// Generates a specified number of mock electricity readings with randomized consumption values.
        /// Readings are created with timestamps going backwards in 10-second intervals from the current time,
        /// then sorted chronologically for realistic time-series data.
        /// </summary>
        /// <param name="number">The number of electricity readings to generate</param>
        /// <returns>A chronologically sorted list of electricity readings</returns>
        public List<ElectricityReading> Generate(int number)
        {
            var readings = new List<ElectricityReading>();
            var random = new Random();
            
            // Generate the specified number of readings
            for (int i = 0; i < number; i++)
            {
                // Create a random reading value between 0 and 1
                var reading = (decimal)random.NextDouble();
                
                // Create electricity reading with timestamp going backwards in time
                var electricityReading = new ElectricityReading
                {
                    Reading = reading,
                    Time = DateTime.Now.AddSeconds(-i * 10)  // Each reading is 10 seconds earlier
                };
                readings.Add(electricityReading);
            }
            
            // Sort readings chronologically (earliest first) for realistic time-series data
            readings.Sort((reading1, reading2) => reading1.Time.CompareTo(reading2.Time));
            return readings;
        }
    }
}
