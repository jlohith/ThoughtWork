﻿using System;

namespace JOIEnergy.Domain
{
    /// <summary>
    /// Represents a single electricity reading from a smart meter.
    /// Contains the timestamp when the reading was taken and the power consumption value.
    /// </summary>
    public class ElectricityReading
    {
        /// <summary>
        /// Gets or sets the date and time when this electricity reading was recorded.
        /// Used for temporal analysis and cost calculations over time periods.
        /// </summary>
        public DateTime Time { get; set; }
        
        /// <summary>
        /// Gets or sets the electricity consumption reading value in kilowatt-hours (kWh).
        /// This represents the cumulative energy consumed up to the time of this reading.
        /// </summary>
        public Decimal Reading { get; set; }
    }
}
