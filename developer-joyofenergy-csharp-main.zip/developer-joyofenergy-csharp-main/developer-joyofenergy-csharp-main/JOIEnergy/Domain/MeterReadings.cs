﻿using System;
using System.Collections.Generic;

namespace JOIEnergy.Domain
{
    /// <summary>
    /// Represents a collection of electricity meter readings for a specific smart meter.
    /// This class serves as a data transfer object for submitting multiple readings at once.
    /// </summary>
    public class MeterReadings
    {
        /// <summary>
        /// Gets or sets the unique identifier for the smart meter device.
        /// This ID is used to associate readings with a specific meter installation.
        /// </summary>
        public string SmartMeterId { get; set; }
        
        /// <summary>
        /// Gets or sets the collection of electricity readings taken from the smart meter.
        /// Each reading contains a timestamp and power consumption value.
        /// </summary>
        public List<ElectricityReading> ElectricityReadings { get; set; }
    }
}
