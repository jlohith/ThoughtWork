﻿using System;
using System.Collections.Generic;
using System.Linq;
using JOIEnergy.Enums;

namespace JOIEnergy.Domain
{
    /// <summary>
    /// Represents an energy price plan with supplier information, unit rates, and peak time multipliers.
    /// This class is used to calculate electricity costs based on different pricing structures.
    /// </summary>
    public class PricePlan
    {
        /// <summary>
        /// Gets or sets the unique name identifier for this price plan.
        /// </summary>
        public string PlanName { get; set; }
        
        /// <summary>
        /// Gets or sets the energy supplier associated with this price plan.
        /// </summary>
        public Supplier EnergySupplier { get; set; }
        
        /// <summary>
        /// Gets or sets the base unit rate per kWh for electricity consumption.
        /// This rate may be modified by peak time multipliers.
        /// </summary>
        public decimal UnitRate { get; set; }
        
        /// <summary>
        /// Gets or sets the collection of peak time multipliers that modify the unit rate
        /// based on the day of the week.
        /// </summary>
        public IList<PeakTimeMultiplier> PeakTimeMultiplier { get; set;}

        /// <summary>
        /// Calculates the price per unit of electricity for a given date and time.
        /// If a peak time multiplier exists for the day of the week, the unit rate is multiplied accordingly.
        /// </summary>
        /// <param name="datetime">The date and time for which to calculate the price</param>
        /// <returns>The calculated price per unit, considering any applicable peak time multipliers</returns>
        public decimal GetPrice(DateTime datetime) {
            // Find the peak time multiplier for the specific day of the week
            var multiplier = PeakTimeMultiplier.FirstOrDefault(m => m.DayOfWeek == datetime.DayOfWeek);

            // Apply multiplier if one exists for this day, otherwise use base unit rate
            if (multiplier?.Multiplier != null) {
                return multiplier.Multiplier * UnitRate;
            } else {
                return UnitRate;
            }
        }
    }

    /// <summary>
    /// Represents a pricing modifier that applies to specific days of the week.
    /// Used to implement peak time pricing where electricity costs more on certain days.
    /// </summary>
    public class PeakTimeMultiplier
    {
        /// <summary>
        /// Gets or sets the day of the week when this multiplier applies.
        /// </summary>
        public DayOfWeek DayOfWeek { get; set; }
        
        /// <summary>
        /// Gets or sets the multiplier value applied to the base unit rate.
        /// Values greater than 1 increase the price, values less than 1 decrease it.
        /// </summary>
        public decimal Multiplier { get; set; }
    }
}
