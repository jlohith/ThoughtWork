﻿using System;
using System.Collections.Generic;
using JOIEnergy.Enums;

namespace JOIEnergy.Services
{
    /// <summary>
    /// Implementation of IAccountService that manages customer account information in memory.
    /// Maintains the association between smart meters and their assigned price plans.
    /// </summary>
    public class AccountService : IAccountService
    { 
        /// <summary>
        /// In-memory storage mapping smart meter IDs to their associated price plan IDs.
        /// </summary>
        private Dictionary<string, string> _smartMeterToPricePlanAccounts;

        /// <summary>
        /// Initializes a new instance of the AccountService with predefined meter-to-price-plan associations.
        /// </summary>
        /// <param name="smartMeterToPricePlanAccounts">Dictionary mapping smart meter IDs to price plan IDs</param>
        public AccountService(Dictionary<string, string> smartMeterToPricePlanAccounts) {
            _smartMeterToPricePlanAccounts = smartMeterToPricePlanAccounts;
        }

        /// <summary>
        /// Retrieves the price plan ID associated with a specific smart meter.
        /// </summary>
        /// <param name="smartMeterId">The unique identifier of the smart meter</param>
        /// <returns>The price plan ID for the meter, or null if no association exists</returns>
        public string GetPricePlanIdForSmartMeterId(string smartMeterId) {
            // Check if meter exists in our account mappings
            if (!_smartMeterToPricePlanAccounts.ContainsKey(smartMeterId))
            {
                return null;
            }
            // Return the associated price plan ID
            return _smartMeterToPricePlanAccounts[smartMeterId];
        }
    }
}
