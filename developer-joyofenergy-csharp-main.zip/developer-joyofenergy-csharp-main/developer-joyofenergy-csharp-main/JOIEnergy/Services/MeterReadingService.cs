﻿using System;
using System.Collections.Generic;
using JOIEnergy.Domain;

namespace JOIEnergy.Services
{
    /// <summary>
    /// Implementation of IMeterReadingService that manages electricity meter readings in memory.
    /// Provides functionality to store and retrieve readings from smart meters using a dictionary-based storage.
    /// </summary>
    public class MeterReadingService : IMeterReadingService
    {
        /// <summary>
        /// Gets or sets the in-memory storage of meter readings, keyed by smart meter ID.
        /// Each meter ID maps to a list of electricity readings for that meter.
        /// </summary>
        public Dictionary<string, List<ElectricityReading>> MeterAssociatedReadings { get; set; }
        
        /// <summary>
        /// Initializes a new instance of the MeterReadingService with pre-existing meter readings.
        /// </summary>
        /// <param name="meterAssociatedReadings">Initial collection of meter readings organized by meter ID</param>
        public MeterReadingService(Dictionary<string, List<ElectricityReading>> meterAssociatedReadings)
        {
            MeterAssociatedReadings = meterAssociatedReadings;
        }

        /// <summary>
        /// Retrieves all electricity readings for a specific smart meter.
        /// </summary>
        /// <param name="smartMeterId">The unique identifier of the smart meter</param>
        /// <returns>A list of electricity readings for the specified meter, or empty list if meter not found</returns>
        public List<ElectricityReading> GetReadings(string smartMeterId) {
            // Check if the meter exists in our storage
            if (MeterAssociatedReadings.ContainsKey(smartMeterId)) {
                return MeterAssociatedReadings[smartMeterId];
            }
            // Return empty list if meter not found
            return new List<ElectricityReading>();
        }

        /// <summary>
        /// Stores a collection of electricity readings for a specific smart meter.
        /// If the meter doesn't exist, it will be created automatically.
        /// New readings are appended to existing readings for the meter.
        /// </summary>
        /// <param name="smartMeterId">The unique identifier of the smart meter</param>
        /// <param name="electricityReadings">The collection of readings to store</param>
        public void StoreReadings(string smartMeterId, List<ElectricityReading> electricityReadings) {
            // Create new meter entry if it doesn't exist
            if (!MeterAssociatedReadings.ContainsKey(smartMeterId)) {
                MeterAssociatedReadings.Add(smartMeterId, new List<ElectricityReading>());
            }

            // Add each new reading to the meter's collection
            electricityReadings.ForEach(electricityReading => MeterAssociatedReadings[smartMeterId].Add(electricityReading));
        }
    }
}
