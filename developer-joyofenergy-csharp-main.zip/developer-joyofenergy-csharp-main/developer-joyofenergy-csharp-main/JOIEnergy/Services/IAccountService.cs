﻿using JOIEnergy.Enums;

namespace JOIEnergy.Services
{
    /// <summary>
    /// Interface for managing customer account information.
    /// Provides functionality to retrieve price plan associations for smart meters.
    /// </summary>
    public interface IAccountService
    {
        /// <summary>
        /// Retrieves the price plan ID associated with a specific smart meter.
        /// </summary>
        /// <param name="smartMeterId">The unique identifier of the smart meter</param>
        /// <returns>The price plan ID for the meter, or null if no association exists</returns>
        string GetPricePlanIdForSmartMeterId(string smartMeterId);
    }
}