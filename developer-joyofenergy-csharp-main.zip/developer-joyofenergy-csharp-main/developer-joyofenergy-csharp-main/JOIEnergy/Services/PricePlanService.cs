﻿using System;
using System.Collections.Generic;
using System.Linq;
using JOIEnergy.Domain;

namespace JOIEnergy.Services
{
    /// <summary>
    /// Implementation of IPricePlanService that performs cost analysis and comparison across different price plans.
    /// Calculates electricity consumption costs based on meter readings and various pricing structures.
    /// </summary>
    public class PricePlanService : IPricePlanService
    {
        /// <summary>
        /// Debug interface for logging purposes. Currently unused but available for debugging.
        /// </summary>
        public interface Debug { void Log(string s); };

        /// <summary>
        /// Collection of available price plans for cost comparison.
        /// </summary>
        private readonly List<PricePlan> _pricePlans;
        
        /// <summary>
        /// Service for retrieving meter readings data.
        /// </summary>
        private IMeterReadingService _meterReadingService;

        /// <summary>
        /// Initializes a new instance of the PricePlanService with available price plans and meter reading service.
        /// </summary>
        /// <param name="pricePlan">List of available price plans for comparison</param>
        /// <param name="meterReadingService">Service to retrieve electricity readings</param>
        public PricePlanService(List<PricePlan> pricePlan, IMeterReadingService meterReadingService)
        {
            _pricePlans = pricePlan;
            _meterReadingService = meterReadingService;
        }

        /// <summary>
        /// Calculates the average electricity reading from a collection of readings.
        /// </summary>
        /// <param name="electricityReadings">Collection of electricity readings</param>
        /// <returns>The average reading value</returns>
        private decimal calculateAverageReading(List<ElectricityReading> electricityReadings)
        {
            // Sum all reading values and calculate average
            var newSummedReadings = electricityReadings.Select(readings => readings.Reading).Aggregate((reading, accumulator) => reading + accumulator);

            return newSummedReadings / electricityReadings.Count();
        }

        /// <summary>
        /// Calculates the total time elapsed between the first and last reading in a collection.
        /// </summary>
        /// <param name="electricityReadings">Collection of electricity readings with timestamps</param>
        /// <returns>Time elapsed in hours as a decimal value</returns>
        private decimal calculateTimeElapsed(List<ElectricityReading> electricityReadings)
        {
            // Find the earliest and latest timestamps
            var first = electricityReadings.Min(reading => reading.Time);
            var last = electricityReadings.Max(reading => reading.Time);

            // Return difference in hours
            return (decimal)(last - first).TotalHours;
        }
        
        /// <summary>
        /// Calculates the total cost of electricity consumption for a specific price plan.
        /// Uses average consumption rate over time and applies the price plan's unit rate.
        /// </summary>
        /// <param name="electricityReadings">Collection of electricity readings</param>
        /// <param name="pricePlan">The price plan to use for cost calculation</param>
        /// <returns>The calculated cost rounded to 3 decimal places</returns>
        private decimal calculateCost(List<ElectricityReading> electricityReadings, PricePlan pricePlan)
        {
            // Calculate consumption metrics
            var average = calculateAverageReading(electricityReadings);
            var timeElapsed = calculateTimeElapsed(electricityReadings);
            
            // Calculate average consumption rate per hour
            var averagedCost = average/timeElapsed;
            
            // Apply price plan rate and round to 3 decimal places
            return Math.Round(averagedCost * pricePlan.UnitRate, 3);
        }

        /// <summary>
        /// Calculates the consumption cost of electricity readings for each available price plan.
        /// This allows customers to compare costs across different pricing models.
        /// </summary>
        /// <param name="smartMeterId">The unique identifier of the smart meter</param>
        /// <returns>Dictionary mapping price plan names to their calculated costs, or empty if no readings found</returns>
        public Dictionary<string, decimal> GetConsumptionCostOfElectricityReadingsForEachPricePlan(string smartMeterId)
        {
            // Retrieve electricity readings for the specified meter
            List<ElectricityReading> electricityReadings = _meterReadingService.GetReadings(smartMeterId);

            // Return empty dictionary if no readings are available
            if (!electricityReadings.Any())
            {
                return new Dictionary<string, decimal>();
            }
            
            // Calculate cost for each price plan and return as dictionary
            return _pricePlans.ToDictionary(plan => plan.PlanName, plan => calculateCost(electricityReadings, plan));
        }
    }
}
