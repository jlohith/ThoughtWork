﻿using System.Collections.Generic;
using JOIEnergy.Domain;

namespace JOIEnergy.Services
{
    /// <summary>
    /// Interface for managing electricity meter readings.
    /// Provides functionality to store and retrieve readings from smart meters.
    /// </summary>
    public interface IMeterReadingService
    {
        /// <summary>
        /// Retrieves all electricity readings for a specific smart meter.
        /// </summary>
        /// <param name="smartMeterId">The unique identifier of the smart meter</param>
        /// <returns>A list of electricity readings for the specified meter, or empty list if meter not found</returns>
        List<ElectricityReading> GetReadings(string smartMeterId);
        
        /// <summary>
        /// Stores a collection of electricity readings for a specific smart meter.
        /// If the meter doesn't exist, it will be created automatically.
        /// </summary>
        /// <param name="smartMeterId">The unique identifier of the smart meter</param>
        /// <param name="electricityReadings">The collection of readings to store</param>
        void StoreReadings(string smartMeterId, List<ElectricityReading> electricityReadings);
    }
}