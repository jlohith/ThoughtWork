﻿using System.Collections.Generic;

namespace JOIEnergy.Services
{
    /// <summary>
    /// Interface for price plan cost analysis services.
    /// Provides functionality to calculate and compare electricity costs across different price plans.
    /// </summary>
    public interface IPricePlanService
    {
        /// <summary>
        /// Calculates the consumption cost of electricity readings for each available price plan.
        /// This allows customers to compare costs across different pricing models.
        /// </summary>
        /// <param name="smartMeterId">The unique identifier of the smart meter</param>
        /// <returns>Dictionary mapping price plan names to their calculated costs, or empty if no readings found</returns>
        Dictionary<string, decimal> GetConsumptionCostOfElectricityReadingsForEachPricePlan(string smartMeterId);
    }
}