﻿using System.Collections.Generic;
using System.Linq;
using JOIEnergy.Enums;
using JOIEnergy.Services;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;

namespace JOIEnergy.Controllers
{
    /// <summary>
    /// API controller for comparing electricity costs across different price plans.
    /// Provides endpoints for cost analysis and price plan recommendations based on smart meter usage.
    /// </summary>
    [Route("price-plans")]
    public class PricePlanComparatorController : Controller
    {
        /// <summary>
        /// JSON key constant for the price plan ID in response objects.
        /// </summary>
        public const string PRICE_PLAN_ID_KEY = "pricePlanId";
        
        /// <summary>
        /// JSON key constant for the price plan comparisons in response objects.
        /// </summary>
        public const string PRICE_PLAN_COMPARISONS_KEY = "pricePlanComparisons";
        
        /// <summary>
        /// Service for calculating price plan costs.
        /// </summary>
        private readonly IPricePlanService _pricePlanService;
        
        /// <summary>
        /// Service for managing customer account information.
        /// </summary>
        private readonly IAccountService _accountService;

        /// <summary>
        /// Initializes a new instance of the PricePlanComparatorController with required dependencies.
        /// </summary>
        /// <param name="pricePlanService">Service for price plan cost calculations</param>
        /// <param name="accountService">Service for account management operations</param>
        public PricePlanComparatorController(IPricePlanService pricePlanService, IAccountService accountService)
        {
            this._pricePlanService = pricePlanService;
            this._accountService = accountService;
        }

        /// <summary>
        /// Calculates and compares electricity costs for all available price plans for a specific smart meter.
        /// Returns the current price plan and cost comparisons across all available plans.
        /// </summary>
        /// <param name="smartMeterId">The unique identifier of the smart meter</param>
        /// <returns>200 OK with cost comparison data, or 404 Not Found if smart meter has no readings</returns>
        [HttpGet("compare-all/{smartMeterId}")]
        public ObjectResult CalculatedCostForEachPricePlan(string smartMeterId)
        {
            // Get the customer's current price plan
            string pricePlanId = _accountService.GetPricePlanIdForSmartMeterId(smartMeterId);
            
            // Calculate costs for all available price plans
            Dictionary<string, decimal> costPerPricePlan = _pricePlanService.GetConsumptionCostOfElectricityReadingsForEachPricePlan(smartMeterId);
            
            // Return 404 if no readings found for the meter
            if (!costPerPricePlan.Any())
            {
                return new NotFoundObjectResult(string.Format("Smart Meter ID ({0}) not found", smartMeterId));
            }

            // Return the current plan and all cost comparisons
            return new ObjectResult(new Dictionary<string, object>() {
                {PRICE_PLAN_ID_KEY, pricePlanId},
                {PRICE_PLAN_COMPARISONS_KEY, costPerPricePlan},
            });
        }

        /// <summary>
        /// Recommends the cheapest price plans for a smart meter, optionally limited to a specific number of recommendations.
        /// Plans are sorted by cost in ascending order (cheapest first).
        /// </summary>
        /// <param name="smartMeterId">The unique identifier of the smart meter</param>
        /// <param name="limit">Optional limit on the number of recommendations to return</param>
        /// <returns>200 OK with recommended price plans sorted by cost, or 404 Not Found if smart meter has no readings</returns>
        [HttpGet("recommend/{smartMeterId}")]
        public ObjectResult RecommendCheapestPricePlans(string smartMeterId, int? limit = null) {
            // Calculate consumption costs for all available price plans
            var consumptionForPricePlans = _pricePlanService.GetConsumptionCostOfElectricityReadingsForEachPricePlan(smartMeterId);

            // Return 404 if no readings found for the meter
            if (!consumptionForPricePlans.Any()) {
                return new NotFoundObjectResult(string.Format("Smart Meter ID ({0}) not found", smartMeterId));
            }

            // Sort price plans by cost (cheapest first)
            var recommendations = consumptionForPricePlans.OrderBy(pricePlanComparison => pricePlanComparison.Value);

            // Apply limit if specified and return appropriate number of recommendations
            if (limit.HasValue && limit.Value < recommendations.Count())
            {
                return new ObjectResult(recommendations.Take(limit.Value));
            }

            // Return all recommendations if no limit or limit exceeds available plans
            return new ObjectResult(recommendations);
        }
    }
}
