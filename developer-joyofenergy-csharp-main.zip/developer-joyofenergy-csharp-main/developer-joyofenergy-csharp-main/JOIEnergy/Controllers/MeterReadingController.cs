﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using JOIEnergy.Domain;
using JOIEnergy.Services;
using Microsoft.AspNetCore.Mvc;

namespace JOIEnergy.Controllers
{
    /// <summary>
    /// API controller for managing electricity meter readings.
    /// Provides endpoints for storing new readings and retrieving existing readings from smart meters.
    /// </summary>
    [Route("readings")]
    public class MeterReadingController : Controller
    {
        /// <summary>
        /// Service for managing meter reading operations.
        /// </summary>
        private readonly IMeterReadingService _meterReadingService;

        /// <summary>
        /// Initializes a new instance of the MeterReadingController with required dependencies.
        /// </summary>
        /// <param name="meterReadingService">Service for meter reading operations</param>
        public MeterReadingController(IMeterReadingService meterReadingService)
        {
            _meterReadingService = meterReadingService;
        }
        
        /// <summary>
        /// Stores a collection of electricity readings for a smart meter.
        /// Validates the input data before storing the readings.
        /// </summary>
        /// <param name="meterReadings">The meter readings data containing smart meter ID and reading values</param>
        /// <returns>200 OK if successful, 400 Bad Request if validation fails</returns>
        [HttpPost ("store")]
        public ObjectResult Post([FromBody]MeterReadings meterReadings)
        {
            // Validate the meter readings data
            if (!IsMeterReadingsValid(meterReadings)) {
                return new BadRequestObjectResult("Internal Server Error");
            }
            
            // Store the readings using the meter reading service
            _meterReadingService.StoreReadings(meterReadings.SmartMeterId,meterReadings.ElectricityReadings);
            return new OkObjectResult("{}");
        }

        /// <summary>
        /// Validates that the meter readings contain required data.
        /// Ensures both smart meter ID and electricity readings are present and not empty.
        /// </summary>
        /// <param name="meterReadings">The meter readings to validate</param>
        /// <returns>True if valid, false otherwise</returns>
        private bool IsMeterReadingsValid(MeterReadings meterReadings)
        {
            string smartMeterId = meterReadings.SmartMeterId;
            List<ElectricityReading> electricityReadings = meterReadings.ElectricityReadings;
            
            // Check that smart meter ID is not null or empty, and readings collection exists and has items
            return smartMeterId != null && smartMeterId.Any()
                    && electricityReadings != null && electricityReadings.Any();
        }

        /// <summary>
        /// Retrieves all electricity readings for a specific smart meter.
        /// </summary>
        /// <param name="smartMeterId">The unique identifier of the smart meter</param>
        /// <returns>200 OK with the collection of electricity readings</returns>
        [HttpGet("read/{smartMeterId}")]
        public ObjectResult GetReading(string smartMeterId) {
            // Retrieve and return the readings for the specified meter
            return new OkObjectResult(_meterReadingService.GetReadings(smartMeterId));
        }
    }
}
